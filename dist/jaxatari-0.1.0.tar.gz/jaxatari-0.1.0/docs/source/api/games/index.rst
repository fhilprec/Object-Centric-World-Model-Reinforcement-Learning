Game Environments
=================

Object-centric environments for Atari games.

.. toctree::
   :maxdepth: 1

   freeway
   kangaroo
   pong
   seaquest
