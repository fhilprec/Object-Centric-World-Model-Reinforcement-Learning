Seaquest Environment
====================

.. automodule:: jaxatari.games.jax_seaquest
   :members:
   :undoc-members:
   :show-inheritance:
